from .inventory_manager import InventoryManagerPlugin


__all__ = ["InventoryManagerPlugin"]